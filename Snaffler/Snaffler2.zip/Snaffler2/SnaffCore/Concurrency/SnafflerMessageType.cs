﻿namespace SnaffCore.Concurrency
{
    public enum SnafflerMessageType
    {
        Error,
        ShareResult,
        DirResult,
        FileResult,
        Finish,
        Info,
        Degub,
        Trace,
        Fatal
    }
}