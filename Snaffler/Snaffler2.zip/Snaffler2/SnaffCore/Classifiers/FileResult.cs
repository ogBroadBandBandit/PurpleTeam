﻿using System;
using System.IO;
using SnaffCore.Classifiers.EffectiveAccess;
using static SnaffCore.Config.Options;

namespace SnaffCore.Classifiers
{
    public class FileResult
    {
        public FileInfo FileInfo { get; set; }
        public TextResult TextResult { get; set; }
        public RwStatus RwStatus { get; set; }
        public ClassifierRule MatchedRule { get; set; }

        public FileResult(FileInfo fileInfo)
        {
            try
            {
                File.OpenRead(fileInfo.FullName);
                this.RwStatus = new RwStatus() { CanRead = true, CanModify = false, CanWrite = false };
            }
            catch (Exception e)
            {
                this.RwStatus = new RwStatus() { CanModify = false, CanRead = false, CanWrite = false };
            }

            this.FileInfo = fileInfo;

            if (MyOptions.Snaffle)
            {
                if ((MyOptions.MaxSizeToSnaffle >= fileInfo.Length) && RwStatus.CanRead)
                {
                    SnaffleFile(fileInfo, MyOptions.SnafflePath);
                }
            }
        }

        public void SnaffleFile(FileInfo fileInfo, string snafflePath)
        {
            string sourcePath = fileInfo.FullName;
            string cleanedPath = sourcePath.Replace(':', '.').Replace('$', '.').Replace("\\\\", "\\");
            cleanedPath = cleanedPath.TrimStart('\\');
            string snaffleFilePath = Path.Combine(snafflePath, cleanedPath);
            
            string snaffleDirPath = Path.GetDirectoryName(snaffleFilePath);
            Directory.CreateDirectory(snaffleDirPath);
            File.Copy(sourcePath, (Path.Combine(snafflePath, cleanedPath)), true);
        }

    }
}