﻿using SnaffCore.Concurrency;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using static SnaffCore.Config.Options;

namespace SnaffCore.Classifiers
{
    public class PostMatchClassifier
    {
        private ClassifierRule ClassifierRule { get; set; }

        public PostMatchClassifier(ClassifierRule inRule)
        {
            this.ClassifierRule = inRule;
        }

        public bool ClassifyPostMatch(FileInfo fileInfo)
        {
            BlockingMq Mq = BlockingMq.GetMq();
            string stringToMatch = null;

            switch (ClassifierRule.MatchLocation)
            {
                case MatchLoc.FileExtension:
                    stringToMatch = fileInfo.Extension;
                    if (stringToMatch == ".bak")
                    {
                        string subName = fileInfo.Name.Replace(".bak", "");
                        stringToMatch = Path.GetExtension(subName);
                        if (stringToMatch == "")
                        {
                            stringToMatch = ".bak";
                        }
                    }
                    if (stringToMatch == "")
                    {
                        return false;
                    }
                    break;
                case MatchLoc.FileName:
                    stringToMatch = fileInfo.Name;
                    break;
                case MatchLoc.FilePath:
                    stringToMatch = fileInfo.FullName;
                    break;
                case MatchLoc.FileLength:
                    if (!SizeMatch(fileInfo))
                    {
                        return false;
                    }
                    else break;
                default:
                    Mq.Error("You've got a misconfigured file classifier rule named " + ClassifierRule.RuleName + ".");
                    return false;
            }

            TextResult textResult = null;

            if (!String.IsNullOrEmpty(stringToMatch))
            {
                TextClassifier textClassifier = new TextClassifier(ClassifierRule);
                textResult = textClassifier.TextMatch(stringToMatch);
                if (textResult == null)
                {
                    return false;
                }
            }

            FileResult fileResult;
            switch (ClassifierRule.MatchAction)
            {
                case MatchAction.Discard:
                    return true;
                default:
                    Mq.Error("You've got a misconfigured PostMatch rule named " + ClassifierRule.RuleName + ". Only the Discard action is supported for PostMatch rules.");
                    return false;
            }

            return false;
        }

        public bool SizeMatch(FileInfo fileInfo)
        {
            if (this.ClassifierRule.MatchLength == fileInfo.Length)
            {
                return true;
            }
            return false;
        }
    }


}