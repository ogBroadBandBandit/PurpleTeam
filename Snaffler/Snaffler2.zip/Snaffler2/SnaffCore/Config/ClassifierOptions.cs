﻿using SnaffCore.Classifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace SnaffCore.Config
{
    public partial class Options
    {
        public List<ClassifierRule> ClassifierRules { get; set; } = new List<ClassifierRule>();
        [Nett.TomlIgnore]
        public List<ClassifierRule> ShareClassifiers { get; set; } = new List<ClassifierRule>();
        [Nett.TomlIgnore]
        public List<ClassifierRule> DirClassifiers { get; set; } = new List<ClassifierRule>();
        [Nett.TomlIgnore]
        public List<ClassifierRule> FileClassifiers { get; set; } = new List<ClassifierRule>();
        [Nett.TomlIgnore]
        public List<ClassifierRule> ContentsClassifiers { get; set; } = new List<ClassifierRule>();
        [Nett.TomlIgnore]
        public List<ClassifierRule> PostMatchClassifiers { get; set; } = new List<ClassifierRule>();

        public void PrepareClassifiers()
        {
            foreach (ClassifierRule classifierRule in ClassifierRules)
            {
                classifierRule.Regexes = new List<Regex>();
                switch (classifierRule.WordListType)
                {
                    case MatchListType.Regex:
                        foreach (string pattern in classifierRule.WordList)
                        {
                            classifierRule.Regexes.Add(new Regex(pattern,
                                RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.CultureInvariant));
                        }

                        break;
                    case MatchListType.Contains:
                        classifierRule.Regexes = new List<Regex>();
                        foreach (string pattern in classifierRule.WordList)
                        {
                            classifierRule.Regexes.Add(new Regex(pattern,
                                RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.CultureInvariant));
                        }

                        break;
                    case MatchListType.EndsWith:
                        foreach (string pattern in classifierRule.WordList)
                        {
                            classifierRule.Regexes.Add(new Regex(pattern + "$",
                                RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.CultureInvariant));
                        }

                        break;
                    case MatchListType.StartsWith:
                        foreach (string pattern in classifierRule.WordList)
                        {
                            classifierRule.Regexes.Add(new Regex("^" + pattern,
                                RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.CultureInvariant));
                        }

                        break;
                    case MatchListType.Exact:
                        foreach (string pattern in classifierRule.WordList)
                        {
                            classifierRule.Regexes.Add(new Regex("^" + pattern + "$",
                                RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.CultureInvariant));
                        }

                        break;

                }
            }

            ClassifierRules = (from classifier in ClassifierRules
                               where IsInterest(classifier)
                               select classifier).ToList();
            ShareClassifiers = (from classifier in ClassifierRules
                                where classifier.EnumerationScope == EnumerationScope.ShareEnumeration
                                select classifier).ToList();
            ShareClassifiers.Sort((x, y) => x.MatchAction.CompareTo(y.MatchAction));
            DirClassifiers = (from classifier in ClassifierRules
                              where classifier.EnumerationScope == EnumerationScope.DirectoryEnumeration
                              select classifier).ToList();
            DirClassifiers.Sort((x, y) => x.MatchAction.CompareTo(y.MatchAction));
            FileClassifiers = (from classifier in ClassifierRules
                               where classifier.EnumerationScope == EnumerationScope.FileEnumeration
                               select classifier).ToList();
            FileClassifiers.Sort((x, y) => x.MatchAction.CompareTo(y.MatchAction));
            ContentsClassifiers = (from classifier in ClassifierRules
                                   where classifier.EnumerationScope == EnumerationScope.ContentsEnumeration
                                   select classifier).ToList();
            ContentsClassifiers.Sort((x, y) => x.MatchAction.CompareTo(y.MatchAction));
            PostMatchClassifiers = (from classifier in ClassifierRules
                where classifier.EnumerationScope == EnumerationScope.PostMatch
                select classifier).ToList();
        }

        private bool IsInterest(ClassifierRule classifier)
        {
            try
            {

                if (classifier.RelayTargets != null)
                {
                    int max = 0;
                    foreach (string relayTarget in classifier.RelayTargets)
                    {
                        try
                        {
                            ClassifierRule relayRule = ClassifierRules.First(thing => thing.RuleName == relayTarget);

                            if (
                                (relayRule.Triage == Triage.Black && InterestLevel > 3) ||
                                (relayRule.Triage == Triage.Red && InterestLevel > 2) ||
                            (relayRule.Triage == Triage.Yellow && InterestLevel > 1) ||
                            (relayRule.Triage == Triage.Green && InterestLevel > 0))
                            {
                                return true;
                            }
                        }
                        catch (Exception e)
                        {
                            throw new Exception("You have a misconfigured rule trying to relay to " + relayTarget + " and no such rule exists by that name.");
                        }
                    }
                }


                bool actualThing = !(
                    (
                        classifier.MatchAction == MatchAction.Snaffle ||
                        classifier.MatchAction == MatchAction.CheckForKeys
                    ) &&
                    (
                    (classifier.Triage == Triage.Black && InterestLevel > 3) ||
                        (classifier.Triage == Triage.Red && InterestLevel > 2) ||
                        (classifier.Triage == Triage.Yellow && InterestLevel > 1) ||
                        (classifier.Triage == Triage.Green && InterestLevel > 0)
                    )
                );
                return actualThing;
            }
            catch (Exception e)
            {
                Console.WriteLine(classifier.RuleName);
                Console.WriteLine(e.ToString());
            }
            return true;
        }
    }
}