﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SnaffCore")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("SnaffCon")]
[assembly: AssemblyProduct("SnaffCore")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("b118802d-2e46-4e41-aac7-9ee890268f8b")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]