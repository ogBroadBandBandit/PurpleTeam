﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.DirectoryServices.ActiveDirectory;
using System.DirectoryServices.Protocols;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using SearchOption = System.DirectoryServices.Protocols.SearchOption;

namespace SnaffCore.ActiveDirectory.LDAP
{
    public class DirectorySearch
    {
        private readonly string _domainController;
        private readonly string _domainName;
        private Domain _domain;
        private readonly string _ldapUsername;
        private readonly string _ldapPassword;
        private readonly int _ldapPort;
        private readonly bool _secureLdap;
        private Dictionary<string, string> _domainGuidMap;
        private bool _isFaulted;
        private DirectoryContext _context;

        private readonly string _baseLdapPath;
        private readonly ConcurrentBag<LdapConnection> _connectionPool = new ConcurrentBag<LdapConnection>();

        public DirectorySearch(string domainName, string domainController, string ldapUserName = null, string ldapPassword = null, int ldapPort = 0, bool secureLdap = false) :
            this(domainName, domainController, $"DC={domainName.Replace(".", ",DC=")}", ldapUserName, ldapPassword, ldapPort, secureLdap){ }

        public DirectorySearch(string domainName, string domainController, string baseLdapPath, string ldapUserName = null, string ldapPassword = null, int ldapPort = 0, bool secureLdap = false)
        {
            _domainName = domainName;
            _baseLdapPath = baseLdapPath;
            _domainController = domainController;
            _domainGuidMap = new Dictionary<string, string>();
            _ldapUsername = ldapUserName;
            _ldapPassword = ldapPassword;
            _ldapPort = ldapPort;
            _secureLdap = secureLdap;
        }

        public string GetDomainName()
        {
            if (_domainName == null)
            {
                SetDomainName();
            }

            return _domainName;
        }

        internal async Task<SearchResultEntry> GetOne(string ldapFilter, string[] props, SearchScope scope, string adsPath = null, bool globalCatalog = false)
        {
            var connection = globalCatalog ? GetGlobalCatalogConnection() : GetLdapConnection();
            try
            {
                var searchRequest = CreateSearchRequest(ldapFilter, scope, props, adsPath);

                var iAsyncResult = connection.BeginSendRequest(searchRequest,
                    PartialResultProcessing.NoPartialResultSupport, null, null);

                var task = Task<SearchResponse>.Factory.FromAsync(iAsyncResult,
                    x => (SearchResponse)connection.EndSendRequest(x));


                var response = await task;

                if (response.Entries.Count == 0)
                    return null;

                return response.Entries[0];
            }
            catch
            {
                return null;
            }
            finally
            {
                if (!globalCatalog)
                    _connectionPool.Add(connection);
                else
                    connection.Dispose();
            }
        }

        internal IEnumerable<SearchResultEntry> QueryLdap(string ldapFilter, string[] props, SearchScope scope, string adsPath = null, bool globalCatalog = false)
        {
            var connection = globalCatalog ? GetGlobalCatalogConnection() : GetLdapConnection();
            try
            {
                var searchRequest = CreateSearchRequest(ldapFilter, scope, props, adsPath);
                var pageRequest = new PageResultRequestControl(500);
                searchRequest.Controls.Add(pageRequest);

                var securityDescriptorFlagControl = new SecurityDescriptorFlagControl
                {
                    SecurityMasks = SecurityMasks.Dacl | SecurityMasks.Owner
                };
                searchRequest.Controls.Add(securityDescriptorFlagControl);

                while (true)
                {
                    SearchResponse searchResponse;
                    try
                    {
                        searchResponse = (SearchResponse)connection.SendRequest(searchRequest);
                    }
                    catch (Exception e)
                    {
                        yield break;
                    }

                    if (searchResponse.Controls.Length != 1 ||
                        !(searchResponse.Controls[0] is PageResultResponseControl))
                    {
                        yield break;
                    }

                    var pageResponse = (PageResultResponseControl)searchResponse.Controls[0];

                    foreach (SearchResultEntry entry in searchResponse.Entries)
                    {
                        yield return entry;
                    }

                    if (pageResponse.Cookie.Length == 0)
                        break;

                    pageRequest.Cookie = pageResponse.Cookie;
                }
            }
            finally
            {
                if (!globalCatalog)
                    _connectionPool.Add(connection);
                else
                    connection.Dispose();
            }
        }

        internal async Task<List<string>> RangedRetrievalAsync(string distinguishedName, string attribute)
        {
            var connection = GetLdapConnection();
            var values = new List<string>();
            try
            {
                var index = 0;
                var step = 0;
                var baseString = $"{attribute}";
                var currentRange = $"{baseString};range={index}-*";
                var searchDone = false;

                var searchRequest = CreateSearchRequest($"{attribute}=*", SearchScope.Base, new[] { currentRange },
                    distinguishedName);

                while (true)
                {
                    var iASyncResult = connection.BeginSendRequest(searchRequest,
                        PartialResultProcessing.NoPartialResultSupport, null, null);
                    var task = Task<SearchResponse>.Factory.FromAsync(iASyncResult, x => (SearchResponse)connection.EndSendRequest(x));

                    var response = await task;

                    if (response?.Entries.Count == 1)
                    {
                        var entry = response.Entries[0];
                        foreach (string attr in entry.Attributes.AttributeNames)
                        {
                            currentRange = attr;
                            searchDone = currentRange.IndexOf("*", 0, StringComparison.Ordinal) > 0;
                            step = entry.Attributes[currentRange].Count;
                        }

                        foreach (string member in entry.Attributes[currentRange].GetValues(typeof(string)))
                        {
                            values.Add(member);
                            index++;
                        }

                        if (searchDone)
                            return values;

                        currentRange = $"{baseString};range={index}-{index + step}";

                        searchRequest.Attributes.Clear();
                        searchRequest.Attributes.Add(currentRange);
                    }
                    else
                    {
                        return values;
                    }
                }
            }
            finally
            {
                _connectionPool.Add(connection);
            }
        }

        internal bool GetAttributeFromGuid(string guid, out string name)
        {
            return _domainGuidMap.TryGetValue(guid, out name);
        }

        private void SetDomainName()
        {
            try
            {
                if (_domainName == null)
                    _domain = Domain.GetCurrentDomain();

                if ((_ldapPassword != null) && (_ldapUsername != null))
                {
                    _context = new DirectoryContext(DirectoryContextType.Domain, _domainName, _ldapUsername,
                        _ldapPassword);
                }
                else
                {
                    _context = new DirectoryContext(DirectoryContextType.Domain, _domainName);
                }

                _domain = Domain.GetDomain(_context);
            }
            catch (Exception e)
            {
                _isFaulted = true;
            }
        }


        private LdapConnection GetGlobalCatalogConnection()
        {
            var domainController = _domainController ?? _domainName;

            var identifier = new LdapDirectoryIdentifier(domainController, 3268);
            var connection = _ldapUsername != null ? new LdapConnection(identifier, new NetworkCredential(_ldapUsername, _ldapPassword)) : new LdapConnection(identifier);

            var ldapSessionOptions = connection.SessionOptions;
            ldapSessionOptions.ProtocolVersion = 3;
            ldapSessionOptions.ReferralChasing = ReferralChasingOptions.None;

            connection.Timeout = new TimeSpan(0, 5, 0);
            return connection;
        }

        private LdapConnection GetLdapConnection()
        {
            if (_connectionPool.TryTake(out var connection))
            {
                return connection;
            }

            var domainController = _domainController ?? _domainName;
            var port = _ldapPort == 0
                ? (_secureLdap ? 636 : 389)
                : _ldapPort;
            var identifier = new LdapDirectoryIdentifier(domainController, port, false, false);

            connection = _ldapUsername != null ? new LdapConnection(identifier, new NetworkCredential(_ldapUsername, _ldapPassword)) : new LdapConnection(identifier);

            var ldapSessionOptions = connection.SessionOptions;
            ldapSessionOptions.ProtocolVersion = 3;
            ldapSessionOptions.ReferralChasing = ReferralChasingOptions.None;
            ldapSessionOptions.SendTimeout = new TimeSpan(0, 0, 10, 0);

            connection.Timeout = new TimeSpan(0, 0, 10, 0);
            return connection;
        }

        private SearchRequest CreateSearchRequest(string ldapFilter, SearchScope scope, string[] props, string adsPath = null)
        {
            var activeDirectorySearchPath = adsPath ?? _baseLdapPath;
            var request = new SearchRequest(activeDirectorySearchPath, ldapFilter, scope, props);
            request.Controls.Add(new SearchOptionsControl(SearchOption.DomainScope));

            return request;
        }

        ~DirectorySearch()
        {
            foreach (var connection in _connectionPool)
            {
                connection.Dispose();
            }
        }
    }
}